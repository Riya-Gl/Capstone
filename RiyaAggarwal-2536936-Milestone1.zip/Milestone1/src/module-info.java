/**
 * 
 */
/**
 * @author riya.aggarwal
 *
 */
module Milestone1 {
	requires java.sql;
}