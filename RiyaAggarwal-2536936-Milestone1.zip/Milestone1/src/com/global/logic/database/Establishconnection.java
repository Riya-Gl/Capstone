package com.global.logic.database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


	public class Establishconnection 
	{
		public static Connection Establishconnection()
		{
			Connection connection=null;
			try {
			
				Class.forName("com.mysql.cj.jdbc.Driver");
				connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/bookshop","root","root");
				} 
			catch (ClassNotFoundException e) {
			
			System.out.println("Inside catch of ClassNotFoundException");
			
		
			} 
		catch (SQLException e) {
			
			System.out.println("Inside catch of SQLException");
			
		}
		return connection;

		
		}
	}

	
	

	 


