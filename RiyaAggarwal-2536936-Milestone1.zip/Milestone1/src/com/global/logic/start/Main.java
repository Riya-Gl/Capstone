package com.global.logic.start;

import java.sql.Connection;
import java.util.Scanner;

import com.global.logic.database.*;
import com.global.logic.mode.*;
import com.global.logic.services.Services;
import com.global.logic.services.bookService;
import com.global.logic.to.BookTO;

public class Main {

	public static void main(String[] args) {

		Connection connection = Establishconnection.Establishconnection();
		Menu mode = new Menu();
		Services service = new Services();
		System.out.println("Welcome to our Online Book Store!!\n");
		Scanner sc = new Scanner(System.in);
		
		
		int mainMenuChoice = sc.nextInt();
		System.out.println("Welcome to our Bookshop\n");
		System.out.println("1. User Mode:");
		System.out.println("2. Admin Mode:");
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter 1 to access User Mode or Enter 2 to access Admin Mode");

		switch (mainMenuChoice) {

		case 1:

			service.register();
	
			break;

		case 2:

		if( service.login() == 1) {
			
			
			List<BookTO> books = bookService.getAllBooks();
			
			for(BookTO to : books) {
				
				System.out.println(to.getId()+", "+to.getName()+", "+to.getPrice());
				
			}
			
			
		}
		else {
			
			System.out.println("Wrong Credentials...");
		}
		break;
		
	case 0:
		System.out.println("Logged-out Successfully...");
	}

}



}
