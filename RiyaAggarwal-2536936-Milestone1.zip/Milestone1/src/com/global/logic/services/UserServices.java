package com.global.logic.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.global.logic.database.Establishconnection;
import com.global.logic.reuse.Reuse;
import com.global.logic.to.BookTO;

public class UserServices 

{
	Connection connection = Establishconnection.Establishconnection();
	int fav;
	Reuse Use = new Reuse();

	public void userServiceMenu() {
		for (;;) {
			Use.clear();
			System.out.println(" ----------------");
			System.out.println("| User Services |");
			System.out.println(" ----------------");
			System.out.println("1. List all books");
			System.out.println("2. Search book by author");
			System.out.println("3. Search book by title");
			System.out.println("4. Search book by publication");
			System.out.println("5. Search book by id");
			System.out.println("6. Add book to favourite");
			System.out.println("7. Add Book to Completed");
			System.out.println("8. Exit");
			int opt = Use.inputINT();
			if (opt == 1) {
				listBooks();
				break;
			} else if (opt == 2) {
				searchByAuthor();
				break;
			} else if (opt == 3) {
				searchByTitle();
				break;
			} else if (opt == 4) {
				searchByPublication();
				break;
			} else if (opt == 5) {
				searchById();
				break;
			} else if (opt == 6) {
				addBookFav();
				break;
			} else if (opt == 7) {
				CompletedBook();
				break;
			}
			else
				Use.error();
		}
	}
	
	private void CompletedBook() {
		// TODO Auto-generated method stub
		
	}

	public void searchById() {
		BookData bd = new BookData();
		int id = ex.inputINT();
		bd.getById(id);
		ex.delay();
		userServiceMenu();
	}

	public void FindAllBooks() 
	{
		
		public List<BookTO> findAllBooks() {
			
			List<BookTO> books = new ArrayList<BookTO>();
			
			try {
				
				PreparedStatement statement = connection.prepareStatement("select * from book");
				
				ResultSet resultSet =  statement.executeQuery();
				while(resultSet.next()) {
					
					int id = resultSet.getInt(1);
					String name = resultSet.getString(2);
					int price = resultSet.getInt(3);
					
					BookTO bookTO = new BookTO(id, name, price);
					books.add(bookTO);
				}
				
			}
			
			catch (Exception e) {
				System.out.println("inside catch of BooKRepo");
			}
			
			return books;
			
			
		}

	}
	}

	}

	public void searchByAuthor() {
		BookData bd = new BookData();
		
	}

	public void searchByTitle() {
		BookData bd = new BookData();
		
	}

	public void searchByPublication() {
		
		String str = Use.inputStr();
		
		userServiceMenu();
	}

	public void addBookFav() {
			}

}
