package com.global.logic.services;

public class bookService {
	
		
		
		
		public List<BookTO> getAllBooks() {
			
			return 	
		}

	}

}
