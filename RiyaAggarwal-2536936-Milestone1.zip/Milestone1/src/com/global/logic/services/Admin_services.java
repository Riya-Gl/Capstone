package com.global.logic.services;
package com.global.logic.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.global.logic.database.*;
import com.global.logic.mode.*;

public class Admin_services {

	
		Connection connection  = Establishconnection.Establishconnection();
		Scanner sc= new Scanner(System.in);
		
		public void login() throws SQLException
		
		{
			Connection connection = Establishconnection.Establishconnection();
			System.out.println("Enter your ID");
			int User_id= sc.nextInt();
			System.out.println("Enter your Password");
			String User_pass= sc.next();
			System.out.println("Enter 0 for user role and 1 for admin role");
			int role=sc.nextInt();
			String str1= "select * from userdata where User_id=? AND User_pass=?";
			PreparedStatement statement= connection.prepareStatement(str1);
			statement.setInt(1, User_id);
			statement.setString(2, User_pass);
			ResultSet resultSet= statement.executeQuery();
			if(resultSet.next()==true)
			{
				System.out.println("Login Successful");
				role = resultSet.getInt(4);
				thread runnable=new thread();
				Thread t1=new Thread(runnable);
				if(role==0)
				{
					t1.setName("user");
					
				}
				else
					t1.setName("admin");
				t1.start();
				
				
			}
			else {
				System.out.println("Login Unsuccessfull, Please try again");
			}
		}
			
		
		public void register() throws SQLException
		{
		
			Connection connection = Establishconnection.Establishconnection();
			System.out.println("Enter your User Id:");
			int User_id=sc.nextInt();
			System.out.println("Enter your User Name:");
			String User_name=sc.next();
			System.out.println("Enter your User Email:");
			String User_email=sc.next();
			System.out.println("Enter your User password");
			String User_pass=sc.next();
			String str="insert into userdata values(?,?,?,?)";
			PreparedStatement statement= connection.prepareStatement(str);
			statement.setInt(1, User_id);
			statement.setString(2, User_name);
			statement.setString(3, User_email);
			statement.setString(4, User_pass);
			statement.executeUpdate();
			System.out.println("register successfully");
			
		}
		public void logout()
		{
			System.out.println("Logout Successfully");
		}

	}


	}

}
