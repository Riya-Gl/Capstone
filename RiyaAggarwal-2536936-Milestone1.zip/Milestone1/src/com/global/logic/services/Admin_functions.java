package com.global.logic.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.global.logic.database.Establishconnection;
import com.global.logic.reuse.Reuse;
import com.global.logic.to.BookTO;

public class Admin_functions 

{
	Connection connection = Establishconnection.Establishconnection();
	Scanner sc = new Scanner(System.in);
	Reuse Use = new Reuse();
	for (;;) {
		
		System.out.println(" ----------------");
		System.out.println("| Admin Services |");
		System.out.println(" ----------------");
		System.out.println("1. Insert book");
		System.out.println("2. Remove Book");
		System.out.println("3. Update book");
		System.out.println("4. Search book");
		System.out.println("5. List All books");
		System.out.println("6. Count total books");
		System.out.println("6. Arrange books");
		System.out.println("6. Exit");
		
		int opt = Use.inputINT();
		if (opt == 1) {
			insertBook();
			break;
		} else if (opt == 2) {
			removeBook();
			break;
		} else if (opt == 3) {
			updateBook();
			break;
		} else if (opt == 4) {
			searchBook();
			break;
		} else if (opt == 5) {
			listAll();
			break;
		} else if (opt == 6) {
			Countbooks();
			break;
		} else if (opt == 7)
			Arrangebooks();
		else
			Use.error();
	}
}

public void insertBook() {
	
	BookTO bookdetails = new BookTO();
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter details of the books you wants to add to the table");
	System.out.println("Enter Book Name");
	String BookName = sc.next();
	System.out.println("Enter Book Id");
	int BookId = sc.nextInt();
	System.out.println("Enter Author Name");
	String authorName = sc.next();
	System.out.println("Enter description");
	String description = sc.next();
	System.out.println("Enter number of copies sold");
	int noOfCopiesSold = sc.nextInt();
	PreparedStatement statement =  connection.prepareStatement("insert into bookdata( BookName , BookId , authorName , description , noOfCopiesSold ) values(?, ?, ?, ?,?)");
	
	statement.setString(1, BookName);
	statement.setInt(2, BookId);
	statement.setString(3, authorName);
	statement.setString(4, description);
	statement.setInt(5, noOfCopiesSold);
	statement.executeUpdate();
}

public void removeBook() {
	BookTO bd = new BookTO();
	System.out.println("Enter Book Id to delete a book");
	int BookId = sc.nextInt();
	PreparedStatement statement =  connection.prepareStatement("delete from bookdata where BookId=?")
	statement.setInt(1, BookId);
}


public void updateBook() {
	BookTO bd = new BookTO();
	System.out.println("Enter book id to be updated:");
	
}

void searchBook() {
	System.out.println(" ----------------");
	System.out.println("| Admin Services |");
	System.out.println(" ----------------");
	System.out.println("1. Search book by Id");
	System.out.println("2. Search book by Author");
	String str ="Update bookdata where BookId=?";
	PreparedStatement statement =  connection.prepareStatement(str);
	statement.SetInt(1,BookId);
	
}

public void searchById() {
	
}

public void searchByAuthor() 
{
	int BookId = sc.nextInt();
	String authorName = sc.next();
	String str = " select BookName from Bookdata where authorName = ?";
	PreparedStatement statement =  connection.prepareStatement(str);
	
	statement.setString(1, authorName);
}
	

public void getAllBooks() {
	List<BookTO> books = new ArrayList<BookTO>();
	
	try {
		
		PreparedStatement statement = connection.prepareStatement("select * from book");
		
		ResultSet resultSet =  statement.executeQuery();
		while(resultSet.next()) {
			
			int id = resultSet.getInt(1);
			String name = resultSet.getString(2);
			int price = resultSet.getInt(3);
			
			BookTO bookTO = new BookTO(id, name, price);
			books.add(bookTO);
		}
		
	}
	
	catch (Exception e) {
		System.out.println("inside catch of BooKRepo");
	}
	
	return books;
	
	
}

}
}
public void Countbooks()
{
	

}
public void Arrangebooks()
{
	
}
}
