package com.global.logic.services;

public class thread implements Runnable {

	@Override
	public void run() {
		if(t1=="user")
		{
			userservices();
		}
		
	}
	
	

}
