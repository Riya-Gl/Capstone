package com.global.logic.reuse;
import java.util.Scanner;

public class Reuse {
	

	    public int inputINT() {
	        Scanner sc = new Scanner(System.in);
	        int input = sc.nextInt();
	        return input;
	    }

	    public String inputStr() {
	        Scanner sc = new Scanner(System.in);
	        String input = sc.nextLine();
	        return input;
	    }
	    
	    public void clear() {
	        System.out.print("\033[H\033[2J");
	        System.out.flush();
	    }

	    public void error() {
	        System.out.println("Wrong Option. Choose again!");
	        try {
	            Thread.sleep(1000);
	        } catch (InterruptedException ex) {
	            ex.printStackTrace();
	        }
	    }
	    
	    public void delay() {
	    	try {
	            Thread.sleep(1000);
	        } catch (InterruptedException ex) {
	            ex.printStackTrace();
	        }
	    }
	}
}
