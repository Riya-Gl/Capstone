package com.global.logic.mode;

import java.sql.Connection;
import java.util.Scanner;

import com.global.logic.database.Establishconnection;
import com.global.logic.services.Admin_services;
import com.global.logic.services.Services;
import com.global.logic.services.User_services;

import Bookshop.EstablishConnection;
import Bookshop.User_access;

public class Menu 
{
	public void Start_Menu()
	{
		
	Connection connection = Establishconnection.Establishconnection();
	
	while(true)
{
	Services access = new Services();
	
	Scanner sc = new Scanner(System.in);
	
	int Mode_choice = sc.nextInt();
	
	System.out.println("Enter 1 to Register:");
	System.out.println("Enter 2 to Login:");
	System.out.println("Enter 3 to LogOut or exit:");
	
	
	try {
		int user_choice=sc.nextInt();

	switch (user_choice) {
	case 1: 
	{
		access.register();
		break;
	case 2: 
	{
		if(Mode_choice==1)
		{
			useraccess.login();
		}
		else
			adminaccess.login();
		
		break;
	}
	case 3:
	{
		useraccess.logout();
	}
	
	}
	}
	
	catch(Exception e){
		System.out.println("Wrong choice entered, pls enter again!!");
		e.printStackTrace();
	}
	finally
	{
		System.out.println("Do you Wish to Continue again?");
		System.out.println("Enter Y to continue or Enter N to stop");
		String wish=sc.next();
		if(wish=="N")
		{
			break;
		}
	}
	
	}
	
} }

}
