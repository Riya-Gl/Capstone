package com.global.logic.to;

public class UserTO {
	
	private String UserName;
	private String FirstName;
	private String LastName;
	private String Userpass;
	
	public UserTO(String userName, String firstName, String lastName, String userpass) {
		super();
		UserName = userName;
		FirstName = firstName;
		LastName = lastName;
		Userpass = userpass;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getFirstName() {
		return FirstName;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getUserpass() {
		return Userpass;
	}
	public void setUserpass(String userpass) {
		Userpass = userpass;
	}
	
}
	
	