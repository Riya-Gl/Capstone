package com.global.logic.to;

import java.util.Scanner;

public class BookTO {
		
		private int BookId ;
		private String BookName;
		private int price;
		private String authorName;
		private String description;
		private String noOfCopiesSold;
		
		public BookTO()
		{
			
		}

		public int getBookId() {
			return BookId;
		}

		public void setBookId(int bookId) {
			BookId = bookId;
		}

		public String getBookName() {
			return BookName;
		}

		public void setBookName(String bookName) {
			BookName = bookName;
		}

		public int getPrice() {
			return price;
		}

		public void setPrice(int price) {
			this.price = price;
		}

		public String getAuthorName() {
			return authorName;
		}

		public void setAuthorName(String authorName) {
			this.authorName = authorName;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

		public String getNoOfCopiesSold() {
			return noOfCopiesSold;
		}

		public void setNoOfCopiesSold(String noOfCopiesSold) {
			this.noOfCopiesSold = noOfCopiesSold;
		}

		public BookTO(int bookId, String bookName, int price, String authorName, String description,
				String noOfCopiesSold) {
			super();
			BookId = bookId;
			BookName = bookName;
			this.price = price;
			this.authorName = authorName;
			this.description = description;
			this.noOfCopiesSold = noOfCopiesSold;
		}
		
		
}
		

		